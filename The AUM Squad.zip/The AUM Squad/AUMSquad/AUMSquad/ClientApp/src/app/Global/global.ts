import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  role: string = 'User';
  loggedIn: boolean = false;
}
