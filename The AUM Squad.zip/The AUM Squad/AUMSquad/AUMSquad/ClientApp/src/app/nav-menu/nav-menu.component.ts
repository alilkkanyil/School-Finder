import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Globals } from '../Global/global';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent {
  isExpanded = false;
  globals: Globals;

  constructor(private router: Router, globals: Globals) {
    this.globals = globals;
  }

  toggled(box) {
    box.style.color = "white";
  var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;
    for (i = 0; i < dropdown.length; i++) {
        dropdown[i].classList.toggle("active");
      var dropdownContent = <HTMLElement>dropdown[i].nextElementSibling;
      if (dropdownContent.style.display === "block") {
          box.style.backgroundColor = "#1d4262";
          dropdownContent.style.display = "none";
        } else {
          box.style.backgroundColor = "#4189C7";
          dropdownContent.style.display = "block";
        }
    }
  }

  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
}
