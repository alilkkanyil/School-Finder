import { Component} from '@angular/core';
import { Globals } from '../Global/global';

@Component({
  selector: 'app-home',
  templateUrl: './login.component.html',
})

export class LoginComponent {
   selected = "User";
   

  constructor(private globals: Globals) {
    this.selected = globals.role;
  }

  changingValue(event) {
    this.globals.role = event.value;
  }

  loggedInClicked() {
    this.globals.loggedIn = true;
  }
}
