import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './school-result.component.html'
})
export class SchoolResultComponent {
  public schools: SchoolResult[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<SchoolResult[]>(baseUrl + 'api/School/Schools').subscribe(result => {
      this.schools = result;
    }, error => console.error(error));
  }
}

interface SchoolResult {
  id: number;
  schoolName: string;
  distance: number;
  schoolType: string;
  generalLevel: string;
}
