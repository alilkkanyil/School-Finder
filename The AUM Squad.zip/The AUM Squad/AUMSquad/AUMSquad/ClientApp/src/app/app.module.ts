import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { Globals } from './Global/global';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { SchoolResultComponent } from './school-result/school-result.component';
import { CreaieSchoolComponent } from './creaie-school/creaie-school.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserSearchComponent } from './user-search/user-search.component';
import { SavedSchoolComponent } from './saved-school/saved-school.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    UserProfileComponent,
    SchoolResultComponent,
    CreaieSchoolComponent,
    UserSearchComponent,
    SavedSchoolComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'user-profile', component: UserProfileComponent },
      { path: 'school-result', component: SchoolResultComponent },
      { path: 'creaie-school', component: CreaieSchoolComponent },
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent },
      { path: 'school-profile', component: CreaieSchoolComponent },
      { path: 'user-search', component: UserSearchComponent },
      { path: 'saved-schools', component: SavedSchoolComponent },
    ])
  ],
  providers: [Globals],
  bootstrap: [AppComponent]
})
export class AppModule { }
