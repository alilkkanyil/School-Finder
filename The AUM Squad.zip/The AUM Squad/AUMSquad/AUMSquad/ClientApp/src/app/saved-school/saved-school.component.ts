import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './saved-school.component.html'
})
export class SavedSchoolComponent {
  public schools: SchoolResult[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<SchoolResult[]>(baseUrl + 'api/School/Schools').subscribe(result => {
      this.schools = result;
    }, error => console.error(error));
  }

  remove(schoolName) {
    var arr = this.schools;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].schoolName === schoolName) {
        arr.splice(i, 1);
      }
    }
  }
}

interface SchoolResult {
  id: number;
  schoolName: string;
  distance: number;
  schoolType: string;
  generalLevel: string;
}
