import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Globals } from '../Global/global';

@Component({
  selector: 'app-creaie-school-component',
  templateUrl: './creaie-school.component.html'
})

export class CreaieSchoolComponent {
  public school: SchoolResult;
  globals: Globals;
  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string, globals: Globals) {
    this.globals = globals;
    http.get<SchoolResult>(baseUrl + 'api/School/GetSchool', {
      params: { id: "1" }
    }).subscribe(result => {
      this.school = result;
    }, error => console.error(error));
  }
}

interface SchoolResult {
  id: number;
  schoolName: string;
  address: string;
  phone: string;
  schoolType: string;
  generalLevel: string;
}
