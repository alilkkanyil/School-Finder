import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './user-search.component.html'
})
export class UserSearchComponent {
  public users: Users[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string, private router: Router) {
    http.get<Users[]>(baseUrl + 'api/UserSearch/Users').subscribe(result => {
      this.users = result;
    }, error => console.error(error));
  }

  btnClick() {
    this.router.navigateByUrl('/school-result');
  };
  
}

interface Users {
  id: number;
  firstName: string;
  lastName: string;
  address: string;
  email: string;
}
