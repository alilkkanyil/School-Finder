import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user-profile-component',
  templateUrl: './user-profile.component.html'
})

export class UserProfileComponent {
  public person: {
    id: number;
    firstName: string;
    lastName: string;
    address: string;
    email: string;
  };

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    var bob = this.person;
    http.get<User>(baseUrl + 'api/UserSearch/GetUser', {
      params: { id: "1" }
    }).subscribe(result => {
     bob.id = result.id;
     bob.firstName = result.firstName;
     bob.lastName = result.lastName;
     bob.address = result.address;
      bob.email = result.email;
    },
      error => console.error(error));
    this.person = bob;
  }
}

interface User {
  id: number;
  firstName: string;
  lastName: string;
  address: string;
  email: string;
}





