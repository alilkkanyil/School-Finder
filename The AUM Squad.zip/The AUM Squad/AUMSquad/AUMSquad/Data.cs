using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AUMSquad
{
    public class SchoolResult
    {
        public SchoolResult(int id, string schoolName, int distance, string schoolType, string generalLevel, string phone, string address)
        {
            Id = id;
            SchoolName = schoolName;
            Distance = distance;
            SchoolType = schoolType;
            GeneralLevel = generalLevel;
            Phone = phone;
            Address = address;
        }
        public int Id { get; set; }
        public string SchoolName { get; set; }
        public int Distance { get; set; }
        public string SchoolType { get; set; }
        public string GeneralLevel { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }

        public static SchoolResult[] GetSchools()
        {
            return new SchoolResult[]
            {
                new SchoolResult(1,"Dalraida Elementary School", 5, "Public","Elementary School", "(334) 975-1000", "123 Main Street"),
                new SchoolResult(2,"Montgomery Public Schools", 12, "Public","Middle school", "(334) 975-1000", "123 Main Street"),
                new SchoolResult(3,"Morningview Elementary School", 7, "Public"," Elementary School", "(334) 975-1000", "123 Main Street"),
                new SchoolResult(4,"Capitol Heights Junior High School", 13, "Public","High School", "(334) 975-1000", "123 Main Street"),
                new SchoolResult(5,"Lee High School", 3, "Public","High School", "(334) 975-1000", "123 Main Street"),
                new SchoolResult(6,"Highland Gardens Elementary", 8, "Public","Elementary School", "(334) 975-1000", "123 Main Street"),
            };
        }
    }

    public class User
    {
        public User(int id, string firstName, string lastName, string address, string email)
        { 
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Email = email;
        }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public static User[] GetUsers()
        {
            return new User[]
            {
                new User(1,"James", "Lake","123 Main Street", "James.Lake@email.com"),
                new User(2,"Thomas", "Paine","123 Main Street", "Thomas.Paine@email.com"),
                new User(3,"Hope", "Stevens","123 Main Street", "Stevens.Lake@email.com"),
                new User(4,"Sarah", "Lee","123 Main Street", "Sarah.Lee@email.com"),
                new User(5,"Adam", "Oliver","123 Main Street", "Adam.Oliver@email.com"),
            };
        }
    }
}