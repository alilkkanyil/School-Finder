using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AUMSquad.Controllers
{
    [Route("api/[controller]")]
    public class SchoolController : Controller
    {
        [HttpGet("[action]")]
        public IEnumerable<SchoolResult> Schools()
        {
            return SchoolResult.GetSchools();
        }

        [HttpGet("[action]")]
        public SchoolResult GetSchool(int id)
        {
            return SchoolResult.GetSchools().FirstOrDefault(x => x.Id == id);
        }
    }
}
