using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AUMSquad.Controllers
{
    [Route("api/[controller]")]
    public class UserSearchController : Controller
    {
        [HttpGet("[action]")]
        public IEnumerable<User> Users()
        {
            return AUMSquad.User.GetUsers();
        }

        [HttpGet("[action]")]
        public User GetUser(int id)
        {
            return AUMSquad.User.GetUsers().FirstOrDefault(x => x.Id == id);
        }
    }
}
